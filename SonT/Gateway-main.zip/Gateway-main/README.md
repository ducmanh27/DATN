# smart-building
IoT wireless sensors for monitoring in smart building

Environment monitoring system based on wireless sensors network

# AUTHORS
Do Tien Hai 20191811

Vu Huy Nhat Minh 20191973

Dinh Hong Quan 20192031

# REFERENCE

This is a gateway branch